"""
حزمة مولد خلاصات RSS
"""

from .rss_generator import RSSGenerator

__all__ = ['RSSGenerator']

